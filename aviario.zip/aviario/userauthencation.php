<?php 

	$host	 = "localhost";
	$user	 = "root";
	$pass 	 ="";
	$banco 	 ="aviario";
		 $conexao = mysql_connect($host,$user,$pass) or die (mysql_error());
		mysql_select_db($banco) or die (mysql_error());
?>
<html>
	<head>
		<meta charset="utf-8">
			<title>Autenticando usuario</title>
				<script type="text/javascript">
		//função javascript para tempo de caregamento da pagina 
				function loginsuccessfully(){
				setTimeout("window.location='painel.php'",5000);

		}
				function loginfailed(){
				setTimeout("window.location='login.php'",5000);
		}


		</script>
	</head>
<body>
<?php
				$email = $_POST["email"];
				$senha = $_POST["senha"];
				$sql = mysql_query("SELECT * FROM usuario WHERE email = '$email' and senha='$senha' ") or die (mysql_error());
					$row = mysql_num_rows($sql);
				if($row > 0){
				session_start();
				$_SESSION['email']= $_POST['email'];
				$_SESSION['senha']= $_POST['senha'];


			 
			 echo "<center>Você foi logado com secesso!!</center>";
			 echo "<script> loginsuccessfully () </script>";
	}
	else{

		echo "<center> Nome do usuario ou senha Invalida!</center>";
		echo "<script> loginfailed ()</script>";
	}

?>


</body>
</html>

