<!DOCTYPE html>
<html>
<head>
	<title>Cadastrar</title>
</head>
<body>

</body>
</html>

<?php 

	$host	 = "localhost";
	$user	 = "root";
	$pass 	 ="";
	$banco 	 ="aviario";
	$conexao = mysql_connect($host,$user,$pass) or die (mysql_error());
		mysql_select_db($banco) or die (mysql_error());
		?>
   <?php
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	$sql = mysql_query("INSERT INTO usuario(email, senha) VALUES('$email','$senha')");

   
header("Location: login.php");

	
?>
		
	
	

</body>
</html>