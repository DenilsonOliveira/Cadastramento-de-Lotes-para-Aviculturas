
<!DOCTYPE>
<html lang="pt-br">

<head>
	<title>Painel</title>
</head>
<body>
    <meta charset="utf-8">
		<link rel="stylesheet"  href="css/estilo.css">
		<link rel="stylesheet"  href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap.css">
	    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
	    <script src="js/jquery.min.js"></script>
	    <script src="js/bootstrap-datepicker.js"></script>

        <div class="container">   
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Novo Cadastro</h3>
            </div>
            <div class="panel-body">
                <form class="form-horizontal" action="lista_cadastro.php" method="post"> 
                    <fieldset>
					  <div class="form-group">
                      <label class="col-md-4 control-label" for="nome">Data</label>  
                      <div class="col-md-4">
                      <input id="data" name="data" type="text" placeholder="" class="datepicker" value="">
                     <script>
       						 $(function(){
           					 $('.datepicker').datepicker();
            
     				   });
   					 </script>
                        
                      </div>
                    </div>

               
                    <div class="form-group">
                      <label class="col-md-4 control-label" for="nome">Idade</label>  
                      <div class="col-md-4">
                      <input id="idade" name="idade" type="text" placeholder="" class="form-control input-md" value="" >

                    </div>
                    </div>
                    <div class="form-group">
                      <label class="col-md-4 control-label" for="nome">Cons-Rac </label>  
                      <div class="col-md-4">
                      <input id="consracm" name="consracm" type="text" placeholder="" class="form-control input-md" value="" >

                    </div>
                    </div>
                    <div class="form-group">
                      <label class="col-md-4 control-label" for="nome">Cons-Àgua</label>  
                      <div class="col-md-4">
                      <input id="consagua" name="consagua" type="text" placeholder="" class="form-control input-md" value="" >

                    </div>
                    </div>
                    <div class="form-group">
                      <label class="col-md-4 control-label" for="nome">Data de Abate</label>  
                      <div class="col-md-4">
                      <input id="dataabate" name="dataabate" type="text" placeholder="" class="form-control input-md" value="" >

                    </div>
                    </div>

					<!-- Button -->
                    <div class="form-group">
                      <label class="col-md-4 control-label" for="btsalvar"></label>
                      <div class="col-md-4">
                        <button id="btsalvar" name="btsalvar" class="btn btn-success">Salvar</button>
                        <a class="btn btn-danger" href="lista_cadastro.php" role="button">Novo</a>
                         <a class="btn btn-primary" href="lista_cadastro.php" role="button">Listar Cadastro</a>
                      </div>
                    </div>

                    </fieldset>
                </form>
            </div>
        </div>
    </div>
		
		
</body>
</html>