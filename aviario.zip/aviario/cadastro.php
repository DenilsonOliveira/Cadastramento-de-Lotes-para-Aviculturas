<!DOCTYPE html>
<html lang="pt-br">
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatile" content="IE=edge">
		<title>Cadastro</title>
		<link rel="stylesheet"  href="css/estilo.css">
		<link rel="stylesheet"  href="css/bootstrap.min.css">
		<script type="text/javascript" src="javascript.js"></script>
	</head>

	<body>
		<body>

		
			<div class="container">
			<form class="form-login" method="POST" action="cadastrar.php" >
			<h2 class="form-login-heading">Cadastre-se</h2>

			<label for="email" class="sr-only"> email </label>

			<input type="text" name="email" class="form-control" placeholder="Digite seu email" required autofocus></input>

			<label for="password" class="sr-only">Senha </label>

			<input type="password" name="senha" class="form-control" placeholder="Senha" required></input>
			

		<button type="submit" value="cadastrar" class="btn btn-lg btn-primary btn-block"> Cadastrar </button>
		</div>

</body>
</html>

