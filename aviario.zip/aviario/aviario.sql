-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 07/04/2016 às 22:33
-- Versão do servidor: 10.1.10-MariaDB
-- Versão do PHP: 5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `aviario`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastrolotes`
--

CREATE TABLE `cadastrolotes` (
  `id` int(11) NOT NULL,
  `data` varchar(25) NOT NULL,
  `idade` varchar(255) NOT NULL,
  `racao` varchar(255) NOT NULL,
  `agua` varchar(255) NOT NULL,
  `dataabate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `cadastrolotes`
--

INSERT INTO `cadastrolotes` (`id`, `data`, `idade`, `racao`, `agua`, `dataabate`) VALUES
(1, '02/01/2016', '13', '', '', '4');

-- --------------------------------------------------------

--
-- Estrutura para tabela `lote`
--

CREATE TABLE `lote` (
  `id` int(11) NOT NULL,
  `data` varchar(255) NOT NULL,
  `idade` varchar(255) NOT NULL,
  `racao` char(255) NOT NULL,
  `agua` varchar(255) NOT NULL,
  `abate` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `lote`
--

INSERT INTO `lote` (`id`, `data`, `idade`, `racao`, `agua`, `abate`) VALUES
(17, '03/01/2016', '12', '123', '3456', '76567'),
(16, '03/11/2016', '16', '543212', '8768976', '12345432'),
(15, '03/03/2016', '14', '1234567', '15', '12345678'),
(20, '03/08/2016', '1122345', '1235', '23144', '123456');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `usuario`
--

INSERT INTO `usuario` (`id`, `email`, `senha`) VALUES
(1, 'denilson@gmail.com', '123456789'),
(10, 'denilsonrpo@hotmail.com', '12345'),
(11, 'denilson@gmail.com', '123456789'),
(12, '', ''),
(13, 'denilson@gmail.com', '123456789'),
(14, 'denilson@gmail.com', '123456789'),
(15, '', ''),
(16, 'denilsonrpoliveira@gmail.com', '1234567890'),
(17, 'denilsonrpoliveira@gmail.com', '1234567890');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `cadastrolotes`
--
ALTER TABLE `cadastrolotes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `lote`
--
ALTER TABLE `lote`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `cadastrolotes`
--
ALTER TABLE `cadastrolotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `lote`
--
ALTER TABLE `lote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=321;
--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
