<?php 
$host = "localhost";
$user = "root";
$pass = "";
$banco = "aviario";
mysql_connect($host,$user,$pass) or die (mysql_error());
mysql_select_db($banco) or die (mysql_error());


//$servidor = mysql_connect("localhost","root","") or die ("Erro ao conectar ao servidor");
//$bd = mysql_select_db("db_lote",$servidor) or die ("Erro ao conectar ao servidor");

 ?>

 