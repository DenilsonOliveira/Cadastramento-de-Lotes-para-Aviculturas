<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lista de Cadastro</title>

   
    <link href="css/vendor/bootstrap.min.css" type="text/css" rel="stylesheet">
	<link href="css/vendor/font-awesome.min.css" type="text/css" rel="stylesheet">
	<link href="css/jquery.bdt.css" type="text/css" rel="stylesheet">
   
  </head>
  <body>
 
    <?php include "conexao.php";?>
  <?php 
  	
  	$sql =mysql_query("SELECT * FROM lote ORDER BY id asc LIMIT 4");
  	$linha=mysql_num_rows($sql);
  ?>
    	  <div class="container">
    	  <div class="panel panel-primary">

          <div class="panel-heading">
    	<h3 class="panel-title">Lista De Cadastros </h3>

    	<form class="form-horizontal" action="lista_cadastro.php" method="post">
        </div>

    	<br></br>
    	 

         <table id="mydatatable" class="table table-bordered table-striped">
    	<thead>
    		
    	<tr>
    			<th class="dissable-sorting">Data</th>
    						
                    <th>Idade</th> 
                    <th>Cons-Rac</th>
                    <th>Cons-Água</th>
                    <th>data de abate</th>
                  
                   


                   
					</tr>
		</thead>
    	<tbody>
    	
    	<?php
    		while ($linha = mysql_fetch_array($sql)) {
    			
    			echo"<tr>";
				echo "<td>".$linha['data']."</td>";
    			echo "<td>".$linha['idade']."</td>";
    			echo "<td>".$linha['racao']."</td>";
    			echo "<td>".$linha['agua']."</td>";
    			echo "<td>".$linha['abate']."</td>";
    			
                echo '<td><a class="btn btn-success" href="painel.php" role="button">Editar</a> </td>';
                echo '<td><a class="btn btn-danger" href="lista_cadastro.php" role="button">Excluir</a> </td>';
                 echo '<td><a class="btn btn-primary" href="painel.php" role="button">Novo Cadastro</a> </td>';
    			echo "</tr>";

    			}
    		 
    	?>
    	</tbody>
		 </table>
		<script src="http://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
		<script src="js/vendor/bootstrap.min.js" type="text/javascript"></script>
		<script src="js/jquery.sortelements.js" type="text/javascript"></script>
		<script src="js/jquery.bdt.js" type="text/javascript"></script>

    <script>
    $(document).ready(function() {
    	$('#mydatatable').bdt({
    	"language": {
                "url": "dataTables.português.lang"
			
      		 
            }
    });
    });

    
    	</script>
        </form>

  </body>
</html>