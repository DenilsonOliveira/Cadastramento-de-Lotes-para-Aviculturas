<!DOCTYPE>
<html>
<head>
	<title>Cadastrando</title>
</head>
<body>
</body>
</html>
<?php 
	$host	 = "localhost";
	$user	 = "root";
	$pass 	 ="";
	$banco 	 ="aviario";
	$conexao = mysql_connect($host,$user,$pass) or die (mysql_error());
		mysql_select_db($banco) or die (mysql_error());
		?>
  <?php
  $data =  $_POST['data'];
  $idade = $_POST['idade'];
  $racao = $_POST["racao"];
  $agua =  $_POST["agua"];
  $abate = $_POST["abate"];
	
	
	
$sql= mysql_query("INSERT INTO lote (data,idade,racao,agua,abate) VALUES('$data','$idade','$racao','$agua','$abate')");

  header("Location: novo_cadastro.php");
?>



		
	
	

