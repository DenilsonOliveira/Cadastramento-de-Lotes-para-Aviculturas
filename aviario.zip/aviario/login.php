

<!DOCTYPE html>
<html lang="pt-br">
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatile" content="IE=edge">
		<title>Login</title>
		<link rel="stylesheet"  href="css/estilo.css">
		<link rel="stylesheet"  href="css/bootstrap.min.css">
		
	</head>

	<body>

	
			<div class="container">
			<form class="form-login" method="POST" action="userauthencation.php">
			<h2 class="form-login-heading">Identifique-se</h2>

			<label for="inputemail" class="sr-only"> Email </label>

			<input type="inputemail" name="email" class="form-control" placeholder="Digite seu email" required autofocus></input>

			<label for="password" class="sr-only">Senha </label>

			<input type="password" name="senha" class="form-control" placeholder="Senha" required></input>
		
		<button type="submit" value="login" class="btn btn-lg btn-primary btn-block"> Login </button>
		 <center><a href="cadastro.php"> Criar uma Conta </a></center>
	</form>
	
		
</body>
</html>


